// Parakleon Configuration
window.PARAKLEON_CONFIG = {
  OPENAI_API_KEY: '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',
  OPENAI_MODEL: 'gpt-4o-mini',
  OLLAMA_BASE_URL: 'http://127.0.0.1:11434/v1'
};
