const CACHE_NAME = 'phonescan-cache-v2'; // Increment version to force update
const ASSETS_TO_CACHE = [
  '/',
  '/pkn.html',
  '/css/main.css',
  '/app.js',
  '/tools.js',
  '/manifest.webmanifest'
];

// Development mode: skip caching entirely
const DEV_MODE = true;

self.addEventListener('install', (ev) => {
  if (!DEV_MODE) {
    ev.waitUntil(
      caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS_TO_CACHE))
    );
  }
  self.skipWaiting();
});

self.addEventListener('activate', (ev) => {
  ev.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.map((k) => caches.delete(k)) // Clear all caches in dev mode
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (ev) => {
  if (DEV_MODE || ev.request.method !== 'GET') {
    // In dev mode, always fetch fresh from network
    return;
  }
  ev.respondWith(
    caches.match(ev.request).then((cached) => {
      if (cached) return cached;
      return fetch(ev.request).then((resp) => {
        // cache a copy for later
        if (resp && resp.status === 200 && resp.type === 'basic') {
          const clone = resp.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(ev.request, clone));
        }
        return resp;
      }).catch(() => caches.match('/pkn.html'));
    })
  );
});
