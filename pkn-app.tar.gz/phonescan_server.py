#!/usr/bin/env python3
"""
Simple PhoneScan API Server for Parakleon
Runs on http://127.0.0.1:5000
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import phonenumbers
from phonenumbers import geocoder, carrier, timezone
import subprocess
import socket
import json
import time
import os
import uuid
from pathlib import Path

app = Flask(__name__)
CORS(app)  # Enable CORS for local development

# Serve the static frontend files (pkn.html, css, js, img, etc.)
ROOT = Path(__file__).parent

@app.route('/')
@app.route('/pkn.html')
def index():
    response = send_from_directory(ROOT, 'pkn.html')
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response


@app.route('/<path:filename>')
def static_files(filename):
    # Serve files from the project root so existing relative paths work
    path = ROOT / filename
    if path.exists() and path.is_file():
        response = send_from_directory(ROOT, filename)
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response
    # Not found — preserve earlier behavior for API routes
    return jsonify({'error': 'Not found'}), 404

@app.route('/api/phonescan', methods=['POST'])
def phonescan():
    try:
        data = request.get_json()
        number = data.get('number', '')
        
        if not number:
            return jsonify({'error': 'No phone number provided'}), 400
        
        # Parse the phone number
        parsed = phonenumbers.parse(number, None)
        
        # Get information
        is_valid = phonenumbers.is_valid_number(parsed)
        country = geocoder.description_for_number(parsed, 'en')
        carrier_name = carrier.name_for_number(parsed, 'en')
        timezones = timezone.time_zones_for_number(parsed)
        number_type = phonenumbers.number_type(parsed)
        
        # Map number type to readable string
        type_map = {
            0: 'Fixed Line',
            1: 'Mobile',
            2: 'Fixed Line or Mobile',
            3: 'Toll Free',
            4: 'Premium Rate',
            5: 'Shared Cost',
            6: 'VoIP',
            7: 'Personal Number',
            8: 'Pager',
            9: 'UAN',
            10: 'Voicemail',
            99: 'Unknown'
        }
        
        result = {
            'number': number,
            'valid': is_valid,
            'country': country or 'Unknown',
            'carrier': carrier_name or 'Unknown',
            'timezones': list(timezones) if timezones else ['Unknown'],
            'type': type_map.get(number_type, 'Unknown'),
            'international_format': phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
            'e164_format': phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164),
            'summary': f"""Phone Number Analysis:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Number: {number}
Valid: {'✓ Yes' if is_valid else '✗ No'}
Country: {country or 'Unknown'}
Carrier: {carrier_name or 'Unknown'}
Type: {type_map.get(number_type, 'Unknown')}
Timezones: {', '.join(timezones) if timezones else 'Unknown'}
International: {phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}
E.164: {phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""
        }
        
        return jsonify(result), 200
        
    except phonenumbers.NumberParseException as e:
        return jsonify({
            'error': f'Invalid phone number format: {str(e)}',
            'summary': f'Error: Invalid phone number format - {str(e)}'
        }), 400
    except Exception as e:
        return jsonify({
            'error': str(e),
            'summary': f'Error: {str(e)}'
        }), 500

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'phonescan'}), 200


# --- Network utility endpoints (backend-powered) ---
@app.route('/api/network/dns', methods=['POST'])
def network_dns():
    try:
        data = request.get_json() or {}
        domain = data.get('domain', '')
        if not domain:
            return jsonify({'error': 'No domain provided'}), 400

        # Simple lookup using socket (returns A/AAAA depending on system resolver)
        try:
            infos = socket.getaddrinfo(domain, None)
            addrs = []
            for info in infos:
                addr = info[4][0]
                if addr not in addrs:
                    addrs.append(addr)
            return jsonify({'domain': domain, 'addresses': addrs}), 200
        except Exception as e:
            return jsonify({'error': f'DNS lookup failed: {str(e)}'}), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/network/ping', methods=['POST'])
def network_ping():
    try:
        data = request.get_json() or {}
        host = data.get('host', '')
        count = int(data.get('count', 4))
        if not host:
            return jsonify({'error': 'No host provided'}), 400

        # Limit count to prevent abuse
        if count < 1 or count > 10:
            count = 4

        # Use system ping (Linux). Capture stdout.
        try:
            proc = subprocess.run(['ping', '-c', str(count), host], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
            out = proc.stdout.strip()
            err = proc.stderr.strip()
            status = proc.returncode
            return jsonify({'host': host, 'count': count, 'returncode': status, 'stdout': out, 'stderr': err}), 200
        except subprocess.TimeoutExpired:
            return jsonify({'error': 'Ping command timed out'}), 500
        except Exception as e:
            return jsonify({'error': f'Ping failed: {str(e)}'}), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/network/portscan', methods=['POST'])
def network_portscan():
    try:
        data = request.get_json() or {}
        host = data.get('host', '')
        ports = data.get('ports', [])
        timeout = float(data.get('timeout', 1.0))

        if not host:
            return jsonify({'error': 'No host provided'}), 400

        # If ports not provided, use common ports
        if not ports:
            ports = [22, 80, 443, 8080]

        # Sanitize ports: only ints, reasonable range, limit number
        clean_ports = []
        for p in ports:
            try:
                pi = int(p)
                if 1 <= pi <= 65535:
                    clean_ports.append(pi)
            except Exception:
                continue
        clean_ports = clean_ports[:30]

        results = []
        for p in clean_ports:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            start = time.time()
            try:
                s.connect((host, p))
                elapsed = (time.time() - start) * 1000.0
                results.append({'port': p, 'open': True, 'rtt_ms': round(elapsed, 2)})
            except socket.timeout:
                results.append({'port': p, 'open': False, 'reason': 'timeout'})
            except Exception as e:
                results.append({'port': p, 'open': False, 'reason': str(e)})
            finally:
                try:
                    s.close()
                except Exception:
                    pass

        return jsonify({'host': host, 'results': results}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# --- File storage endpoints ---
UPLOAD_DIR = Path(__file__).parent / 'uploads'
META_FILE = UPLOAD_DIR / 'files.json'
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def _load_meta():
    try:
        if META_FILE.exists():
            return json.loads(META_FILE.read_text())
    except Exception:
        pass
    return {}

def _save_meta(meta):
    try:
        META_FILE.write_text(json.dumps(meta, indent=2))
    except Exception:
        pass


@app.route('/api/files/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400
        f = request.files['file']
        if f.filename == '':
            return jsonify({'error': 'No selected file'}), 400

        # generate id and store
        fid = str(uuid.uuid4())
        safe_name = os.path.basename(f.filename)
        dest = UPLOAD_DIR / f"{fid}_{safe_name}"
        f.save(dest)

        # basic metadata
        meta = _load_meta()
        meta[fid] = {
            'id': fid,
            'filename': safe_name,
            'stored_name': dest.name,
            'size': dest.stat().st_size,
            'uploaded_at': int(time.time())
        }
        _save_meta(meta)

        return jsonify({'id': fid, 'filename': safe_name, 'size': meta[fid]['size']}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/files/list', methods=['GET'])
def list_files():
    try:
        meta = _load_meta()
        files = list(meta.values())
        # sort by uploaded_at desc
        files.sort(key=lambda x: x.get('uploaded_at', 0), reverse=True)
        return jsonify({'files': files}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/files/<file_id>/summary', methods=['GET'])
def file_summary(file_id):
    try:
        meta = _load_meta()
        entry = meta.get(file_id)
        if not entry:
            return jsonify({'error': 'File not found'}), 404

        path = UPLOAD_DIR / entry['stored_name']
        if not path.exists():
            return jsonify({'error': 'Stored file missing'}), 404

        # Only attempt to read text files (simple heuristic)
        try:
            text = path.read_text(errors='ignore')
        except Exception as e:
            return jsonify({'error': f'Could not read file: {str(e)}'}), 500

        snippet = text[:3000]
        # simple summary: first 500 chars + top words
        first = snippet[:500]
        words = [w.strip('.,:;"\'"()[]{}').lower() for w in snippet.split()]
        stop = set(['the', 'and', 'for', 'that', 'with', 'this', 'from', 'are', 'was', 'were', 'have', 'has', 'will', 'you', 'your', 'not', 'but', 'can', 'our', 'all', 'any', 'too', 'its', "it's"])
        freq = {}
        for w in words:
            if len(w) < 3 or w in stop: continue
            freq[w] = freq.get(w, 0) + 1
        top = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:8]
        keywords = [k for k,v in top]

        return jsonify({'id': file_id, 'filename': entry['filename'], 'summary': first, 'keywords': keywords}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Run PhoneScan API server')
    parser.add_argument('--host', default='127.0.0.1', help='Host to bind (default: 127.0.0.1)')
    parser.add_argument('--port', type=int, default=5000, help='Port to bind (default: 5000)')
    parser.add_argument('--debug', action='store_true', help='Run Flask in debug mode')
    args = parser.parse_args()

    print("=" * 50)
    print("PhoneScan API Server")
    print("=" * 50)
    print(f"Running on: http://{args.host}:{args.port}")
    print("Endpoint: POST /api/phonescan")
    print("Health check: GET /health")
    print("=" * 50)
    app.run(host=args.host, port=args.port, debug=args.debug)
