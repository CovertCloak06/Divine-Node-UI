// Parakleon Main Chat Application
const messagesContainer = document.getElementById('messagesContainer');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const historyList = document.getElementById('historyList');
const favoritesList = document.getElementById('favoritesList');
const archiveList = document.getElementById('archiveList');
const projectsList = document.getElementById('projectsList');
const fileInput = document.getElementById('fileInput');
const filePreview = document.getElementById('filePreview');
const fileActions = document.getElementById('fileActions');
const modelSelect = document.getElementById('modelSelect');
const settingsOverlay = document.getElementById('settingsOverlay');
const fullHistoryToggle = document.getElementById('fullHistoryToggle');
const stopBtn = document.getElementById('stopBtn');

let isWaiting = false;
let abortController = null;
let currentChatId = null;
let currentProjectId = null;
let thinkingInterval = null;
let editingMessageId = null;
const STORAGE_KEY = 'parakleon_chats_v1';
const PROJECTS_KEY = 'parakleon_projects_v1';
const MAX_SHORT_HISTORY = 8;

let ACTIVE_BASE_URL = 'https://api.openai.com/v1/chat/completions';
let ACTIVE_MODEL = window.PARAKLEON_CONFIG.OPENAI_MODEL;
let ACTIVE_API_KEY = window.PARAKLEON_CONFIG.OPENAI_API_KEY;

console.log('Initial ACTIVE_MODEL:', ACTIVE_MODEL);

function onModelChange() {
    const value = modelSelect.value;
    if (value === 'openai') {
        ACTIVE_BASE_URL = 'https://api.openai.com/v1/chat/completions';
        ACTIVE_MODEL = window.PARAKLEON_CONFIG.OPENAI_MODEL;
        ACTIVE_API_KEY = window.PARAKLEON_CONFIG.OPENAI_API_KEY;
    } else if (value.startsWith('ollama:')) {
        const modelName = value.replace('ollama:', '');
        ACTIVE_BASE_URL = window.PARAKLEON_CONFIG.OLLAMA_BASE_URL + '/chat/completions';
        ACTIVE_MODEL = modelName;
        ACTIVE_API_KEY = 'ollama';
    }
}

function toggleSettings() {
    const visible = settingsOverlay.style.display === 'flex';
    if (!visible) {
        const chats = loadChatsFromStorage();
        const chat = getCurrentChat(chats);
        fullHistoryToggle.checked = chat ? !!chat.useFullHistory : true;
    }
    settingsOverlay.style.display = visible ? 'none' : 'flex';
}

function toggleFullHistory() {
    let chats = loadChatsFromStorage();
    const chat = getCurrentChat(chats);
    if (chat) {
        chat.useFullHistory = !!fullHistoryToggle.checked;
        chat.updatedAt = Date.now();
        saveChatsToStorage(chats);
        renderHistory();
    }
}

function confirmDeleteAllChats() {
    if (confirm('Are you sure you want to delete all chats? This cannot be undone.')) {
        localStorage.removeItem('parakleon_chats_v1');
        localStorage.removeItem('currentChatId');
        currentChatId = null;
        messagesContainer.innerHTML = '';
        toggleSettings();
        renderHistory(); // Re-render to show the "+ New chat" button
        // Show system message without saving to chat
        const systemDiv = document.createElement('div');
        systemDiv.className = 'message system-message';
        systemDiv.textContent = 'All chats deleted.';
        messagesContainer.appendChild(systemDiv);
    }
}

function confirmDeleteAllProjects() {
    if (confirm('Are you sure you want to delete all projects? This will delete all project chats and cannot be undone.')) {
        localStorage.removeItem('parakleon_projects_v1');
        if (currentProjectId) {
            currentProjectId = null;
            currentChatId = null;
            messagesContainer.innerHTML = '';
        }
        toggleSettings();
        renderProjects();
        renderHistory();
        // Show system message without saving to chat
        const systemDiv = document.createElement('div');
        systemDiv.className = 'message system-message';
        systemDiv.textContent = 'All projects deleted.';
        messagesContainer.appendChild(systemDiv);
    }
}

function loadChatsFromStorage() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return [];
        return JSON.parse(raw);
    } catch (e) {
        console.error('Failed to load history', e);
        return [];
    }
}

function saveChatsToStorage(chats) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(chats));
    } catch (e) {
        console.error('Failed to save history', e);
    }
}

function sortChats(chats) {
    return chats.sort((a, b) => {
        const aTime = a.updatedAt || 0;
        const bTime = b.updatedAt || 0;
        return bTime - aTime;
    });
}

function renderHistory() {
    historyList.innerHTML = '';
    favoritesList.innerHTML = '';
    archiveList.innerHTML = '';

    let chats = loadChatsFromStorage();
    chats = sortChats(chats);

    // Add "+ New chat" button at the top of chats list
    const newChatBtn = document.createElement('div');
    newChatBtn.className = 'history-item new-chat-btn';
    newChatBtn.innerHTML = '<span class="history-title">+ New chat</span>';
    newChatBtn.onclick = () => {
        newChat();
    };
    historyList.appendChild(newChatBtn);

    chats.forEach(chat => {
        const item = document.createElement('div');
        item.className = 'history-item' + (chat.id === currentChatId ? ' active' : '');
        item.dataset.chatId = chat.id;

        const title = document.createElement('span');
        title.className = 'history-title';
        title.textContent = chat.title || 'Untitled chat';
        title.onclick = (e) => {
            e.stopPropagation();
            loadChat(chat.id);
        };
        item.appendChild(title);

        const menuBtn = document.createElement('button');
        menuBtn.className = 'history-menu-btn';
        menuBtn.textContent = '⋮';
        menuBtn.onclick = (e) => {
            e.stopPropagation();
            openHistoryMenu(chat.id, menuBtn, !!chat.starred, !!chat.archived);
        };
        item.appendChild(menuBtn);

        if (chat.archived) {
            archiveList.appendChild(item);
        } else if (chat.starred) {
            favoritesList.appendChild(item);
        } else {
            historyList.appendChild(item);
        }
    });
}

let openMenuElement = null;

function closeHistoryMenu() {
    if (openMenuElement && openMenuElement.parentNode) {
        openMenuElement.parentNode.removeChild(openMenuElement);
    }
    openMenuElement = null;
}

function openHistoryMenu(chatId, anchorButton, isStarred, isArchived) {
    closeHistoryMenu();

    const rect = anchorButton.getBoundingClientRect();
    const containerRect = document.body.getBoundingClientRect();

    const menu = document.createElement('div');
    menu.className = 'history-menu';

    const favItem = document.createElement('div');
    favItem.className = 'history-menu-item';
    favItem.textContent = isStarred ? 'Unfavorite' : 'Add to favorites';
    favItem.onclick = () => {
        toggleFavoriteChat(chatId);
        closeHistoryMenu();
    };
    menu.appendChild(favItem);

    const archItem = document.createElement('div');
    archItem.className = 'history-menu-item';
    archItem.textContent = isArchived ? 'Unarchive' : 'Archive chat';
    archItem.onclick = () => {
        toggleArchiveChat(chatId);
        closeHistoryMenu();
    };
    menu.appendChild(archItem);

    const renameItem = document.createElement('div');
    renameItem.className = 'history-menu-item';
    renameItem.textContent = 'Rename chat';
    renameItem.onclick = () => {
        renameChatPrompt(chatId);
        closeHistoryMenu();
    };
    menu.appendChild(renameItem);

    const moveItem = document.createElement('div');
    moveItem.className = 'history-menu-item';
    moveItem.textContent = 'Move to Project';
    moveItem.onclick = () => {
        showMoveToProjectModal(chatId);
        closeHistoryMenu();
    };
    menu.appendChild(moveItem);

    const deleteItem = document.createElement('div');
    deleteItem.className = 'history-menu-item';
    deleteItem.textContent = 'Delete chat';
    deleteItem.onclick = () => {
        deleteChat(chatId);
        closeHistoryMenu();
    };
    menu.appendChild(deleteItem);

    const top = rect.bottom - containerRect.top + window.scrollY;
    const left = rect.left - containerRect.left + window.scrollX;
    menu.style.top = top + 'px';
    menu.style.left = left + 'px';

    document.body.appendChild(menu);
    openMenuElement = menu;
}

document.addEventListener('click', (e) => {
    if (openMenuElement && !openMenuElement.contains(e.target) && !e.target.classList.contains('history-menu-btn')) {
        closeHistoryMenu();
    }
});

function toggleFavoriteChat(id) {
    let chats = loadChatsFromStorage();
    const chat = chats.find(c => c.id === id);
    if (chat) {
        chat.starred = !chat.starred;
        chat.updatedAt = Date.now();
        saveChatsToStorage(chats);
        renderHistory();
    }
}

function toggleArchiveChat(id) {
    let chats = loadChatsFromStorage();
    const chat = chats.find(c => c.id === id);
    if (chat) {
        chat.archived = !chat.archived;
        chat.updatedAt = Date.now();
        saveChatsToStorage(chats);
        renderHistory();
    }
}

function getCurrentChat(chats) {
    return chats.find(c => c.id === currentChatId);
}

function ensureCurrentChat() {
    if (currentProjectId) {
        // Project mode: use project chats
        const projects = loadProjectsFromStorage();
        const project = projects.find(p => p.id === currentProjectId);
        
        if (project) {
            if (!project.chats) project.chats = [];
            
            // If we have a current chat ID and it exists in project, we're good
            if (currentChatId && project.chats.find(c => c.id === currentChatId)) {
                return;
            }
            
            // Create new chat in project
            const id = 'chat_' + Date.now();
            const chat = {
                id,
                title: 'Project Chat',
                messages: [],
                starred: false,
                archived: false,
                useFullHistory: true,
                updatedAt: Date.now()
            };
            project.chats.unshift(chat);
            currentChatId = id;
            saveProjectsToStorage(projects);
        }
    } else {
        // Global mode: use global chats
        let chats = loadChatsFromStorage();
        
        // If we have a current chat ID and it exists, we're good
        if (currentChatId && getCurrentChat(chats)) {
            return;
        }
        
        // Create new global chat
        const id = 'chat_' + Date.now();
        const chat = {
            id,
            title: 'New chat',
            messages: [],
            starred: false,
            archived: false,
            useFullHistory: true,
            updatedAt: Date.now()
        };
        chats.unshift(chat);
        currentChatId = id;
        saveChatsToStorage(chats);
        renderHistory();
    }
}

function appendMessageToCurrentChat(sender, text, attachments = [], messageId = null, model = null) {
    ensureCurrentChat();
    
    let chat = null;
    if (currentProjectId) {
        // Get chat from project
        const projects = loadProjectsFromStorage();
        const project = projects.find(p => p.id === currentProjectId);
        if (project && project.chats) {
            chat = project.chats.find(c => c.id === currentChatId);
        }
        
        if (chat) {
            const now = Date.now();
            if (editingMessageId && sender === 'user' && messageId) {
                const idx = chat.messages.findIndex(m => m.id === messageId);
                if (idx !== -1) {
                    chat.messages[idx].text = text;
                    chat.messages[idx].attachments = attachments;
                    // Remove all messages after this edited message
                    chat.messages = chat.messages.slice(0, idx + 1);
                }
                editingMessageId = null;
                saveProjectsToStorage(projects);
                // Reload chat to show changes
                setTimeout(() => reloadCurrentChat(), 100);
                return;
            } else {
                const id = 'msg_' + now + '_' + Math.floor(Math.random() * 10000);
                const message = {id, sender, text, attachments};
                if (model) message.model = model;
                chat.messages.push(message);
            }
            if (chat.title === 'Project Chat' && sender === 'user') {
                chat.title = text.slice(0, 30);
            }
            if (chat.useFullHistory === undefined) chat.useFullHistory = true;
            chat.updatedAt = now;
            saveProjectsToStorage(projects);
        }
    } else {
        // Get chat from global storage
        let chats = loadChatsFromStorage();
        chat = getCurrentChat(chats);
        
        if (chat) {
            const now = Date.now();
            if (editingMessageId && sender === 'user' && messageId) {
                const idx = chat.messages.findIndex(m => m.id === messageId);
                if (idx !== -1) {
                    chat.messages[idx].text = text;
                    chat.messages[idx].attachments = attachments;
                    // Remove all messages after this edited message
                    chat.messages = chat.messages.slice(0, idx + 1);
                }
                editingMessageId = null;
                saveChatsToStorage(chats);
                renderHistory();
                // Reload chat to show changes
                setTimeout(() => reloadCurrentChat(), 100);
                return;
            } else {
                const id = 'msg_' + now + '_' + Math.floor(Math.random() * 10000);
                const message = {id, sender, text, attachments};
                if (model) message.model = model;
                chat.messages.push(message);
            }
            if (chat.title === 'New chat' && sender === 'user') {
                chat.title = text.slice(0, 30);
            }
            if (chat.useFullHistory === undefined) chat.useFullHistory = true;
            chat.updatedAt = now;
            saveChatsToStorage(chats);
            renderHistory();
        }
    }
}

function loadChat(id) {
    const chats = loadChatsFromStorage();
    const chat = chats.find(c => c.id === id);
    if (!chat) return;
    currentProjectId = null; // Exit project mode when loading a global chat
    currentChatId = id;
    messagesContainer.innerHTML = '';
    chat.messages.forEach(m => addMessage(m.text, m.sender, false, m.attachments, m.id, m.model));
    fullHistoryToggle.checked = chat.useFullHistory !== false;
    renderProjects();
    renderHistory();
}

function reloadCurrentChat() {
    if (!currentChatId) return;
    
    messagesContainer.innerHTML = '';
    
    if (currentProjectId) {
        // Reload project chat
        const projects = loadProjectsFromStorage();
        const project = projects.find(p => p.id === currentProjectId);
        if (project && project.chats) {
            const chat = project.chats.find(c => c.id === currentChatId);
            if (chat && chat.messages) {
                chat.messages.forEach(m => addMessage(m.text, m.sender, false, m.attachments || [], m.id, m.model));
            }
        }
    } else {
        // Reload global chat
        const chats = loadChatsFromStorage();
        const chat = chats.find(c => c.id === currentChatId);
        if (chat && chat.messages) {
            chat.messages.forEach(m => addMessage(m.text, m.sender, false, m.attachments, m.id, m.model));
        }
    }
}

function deleteChat(id) {
    let chats = loadChatsFromStorage();
    chats = chats.filter(c => c.id !== id);
    saveChatsToStorage(chats);
    if (currentChatId === id) {
        currentChatId = null;
        messagesContainer.innerHTML = '';
    }
    renderHistory();
}

function renameChatPrompt(chatId) {
    const chats = loadChatsFromStorage();
    const chat = chats.find(c => c.id === chatId);
    if (!chat) return;
    
    const newTitle = prompt('Enter new chat name:', chat.title);
    if (newTitle !== null && newTitle.trim() !== '') {
        renameChat(chatId, newTitle.trim());
    }
}

function renameChat(chatId, newTitle) {
    const chats = loadChatsFromStorage();
    const chat = chats.find(c => c.id === chatId);
    if (chat) {
        chat.title = newTitle;
        chat.updatedAt = Date.now();
        saveChatsToStorage(chats);
        renderHistory();
    }
}

function newChat() {
    currentProjectId = null; // Exit project mode
    const id = 'chat_' + Date.now();
    const chats = loadChatsFromStorage();
    chats.unshift({
        id,
        title: 'New chat',
        messages: [],
        starred: false,
        archived: false,
        useFullHistory: true,
        updatedAt: Date.now()
    });
    saveChatsToStorage(chats);
    currentChatId = id;
    messagesContainer.innerHTML = '';
    renderProjects();
    renderHistory();
}

function backupChat() {
    const chats = loadChatsFromStorage();
    const blob = new Blob([JSON.stringify(chats, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'parakleon_chat_backup.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    alert('Backup downloaded.');
}

// ===== PROJECTS MANAGEMENT =====
function loadProjectsFromStorage() {
    try {
        const raw = localStorage.getItem(PROJECTS_KEY);
        if (!raw) return [];
        return JSON.parse(raw);
    } catch (e) {
        console.error('Failed to load projects', e);
        return [];
    }
}

function saveProjectsToStorage(projects) {
    try {
        localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
    } catch (e) {
        console.error('Failed to save projects', e);
    }
}

function createNewProject() {
    const modal = document.getElementById('projectModal');
    if (modal) {
        modal.style.display = 'flex';
        document.getElementById('projectName').value = '';
        document.getElementById('projectPrompt').value = '';
        document.getElementById('projectFilesList').innerHTML = '';
        window.projectModalFiles = [];
    }
}

function closeProjectModal() {
    const modal = document.getElementById('projectModal');
    if (modal) modal.style.display = 'none';
}

function showMoveToProjectModal(chatId) {
    const modal = document.getElementById('moveToProjectModal');
    const list = document.getElementById('moveToProjectList');
    
    if (!modal || !list) return;
    
    const projects = loadProjectsFromStorage();
    list.innerHTML = '';
    
    if (projects.length === 0) {
        list.innerHTML = '<p style="color: #999; text-align: center; padding: 20px;">No projects available. Create a project first.</p>';
    } else {
        projects.forEach(project => {
            const item = document.createElement('div');
            item.className = 'project-file-item';
            item.style.cursor = 'pointer';
            item.style.padding = '12px';
            item.style.marginBottom = '8px';
            item.style.border = '1px solid #333';
            item.style.borderRadius = '4px';
            item.style.transition = 'background 0.2s';
            item.innerHTML = `<strong>${escapeHtml(project.name)}</strong>`;
            if (project.description) {
                item.innerHTML += `<br><small style="color: #999;">${escapeHtml(project.description)}</small>`;
            }
            item.onmouseover = () => item.style.background = '#222';
            item.onmouseout = () => item.style.background = '';
            item.onclick = () => {
                moveChatToProject(chatId, project.id);
                closeMoveToProjectModal();
            };
            list.appendChild(item);
        });
    }
    
    modal.style.display = 'flex';
}

function closeMoveToProjectModal() {
    const modal = document.getElementById('moveToProjectModal');
    if (modal) modal.style.display = 'none';
}

function moveChatToProject(chatId, projectId) {
    // Get the chat from global storage
    let chats = loadChatsFromStorage();
    const chatIndex = chats.findIndex(c => c.id === chatId);
    
    if (chatIndex === -1) {
        alert('Chat not found.');
        return;
    }
    
    const chat = chats[chatIndex];
    
    // Get the project
    const projects = loadProjectsFromStorage();
    const project = projects.find(p => p.id === projectId);
    
    if (!project) {
        alert('Project not found.');
        return;
    }
    
    // Move chat to project
    if (!project.chats) project.chats = [];
    project.chats.unshift(chat);
    
    // Remove from global chats
    chats.splice(chatIndex, 1);
    
    // Save both
    saveChatsToStorage(chats);
    saveProjectsToStorage(projects);
    
    // Update UI
    if (currentChatId === chatId) {
        currentChatId = null;
        messagesContainer.innerHTML = '';
    }
    renderHistory();
    
    // Show confirmation
    const systemDiv = document.createElement('div');
    systemDiv.className = 'message system-message';
    systemDiv.textContent = `Chat moved to project "${project.name}".`;
    messagesContainer.appendChild(systemDiv);
}

function handleProjectFiles() {
    const input = document.getElementById('projectFilesInput');
    const filesList = document.getElementById('projectFilesList');
    if (!input.files || !input.files.length) return;
    
    window.projectModalFiles = window.projectModalFiles || [];
    
    Array.from(input.files).forEach(file => {
        window.projectModalFiles.push(file);
        const fileItem = document.createElement('div');
        fileItem.className = 'project-file-item';
        fileItem.innerHTML = `<span>${escapeHtml(file.name)}</span><button onclick="removeProjectFile('${escapeHtml(file.name)}')">×</button>`;
        filesList.appendChild(fileItem);
    });
    
    input.value = '';
}

function removeProjectFile(fileName) {
    window.projectModalFiles = (window.projectModalFiles || []).filter(f => f.name !== fileName);
    const filesList = document.getElementById('projectFilesList');
    Array.from(filesList.children).forEach(item => {
        if (item.textContent.includes(fileName)) item.remove();
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function saveNewProject() {
    const name = document.getElementById('projectName').value.trim();
    const systemPrompt = document.getElementById('projectPrompt').value.trim();
    const files = window.projectModalFiles || [];
    
    if (!name) {
        alert('Please enter a project name.');
        return;
    }
    
    const projects = loadProjectsFromStorage();
    const projectId = 'project_' + Date.now();
    const chatId = 'chat_' + Date.now();
    
    // Upload project files to server
    const uploadedFiles = [];
    for (const file of files) {
        try {
            const fd = new FormData();
            fd.append('file', file);
            const resp = await fetch('/api/files/upload', { method: 'POST', body: fd });
            const j = await resp.json();
            if (resp.ok) {
                uploadedFiles.push({
                    id: j.id,
                    filename: j.filename,
                    storedName: j.stored_name,
                    size: file.size,
                    uploadedAt: Date.now()
                });
            }
        } catch (e) {
            console.error('File upload failed:', e);
        }
    }
    
    // Create first chat for the project
    const firstChat = {
        id: chatId,
        title: 'Project Chat',
        messages: [],
        starred: false,
        archived: false,
        useFullHistory: true,
        updatedAt: Date.now()
    };
    
    // Add system prompt as first message if provided
    if (systemPrompt) {
        firstChat.messages.push({
            id: 'msg_' + Date.now(),
            sender: 'system',
            text: 'System Prompt: ' + systemPrompt,
            timestamp: Date.now()
        });
    }
    
    projects.push({
        id: projectId,
        name: name,
        systemPrompt: systemPrompt,
        description: '',
        chats: [firstChat],
        files: uploadedFiles,
        images: [],
        createdAt: Date.now(),
        updatedAt: Date.now()
    });
    
    saveProjectsToStorage(projects);
    currentProjectId = projectId;
    currentChatId = chatId;
    renderProjects();
    closeProjectModal();
    
    // Load the project's first chat
    messagesContainer.innerHTML = '';
    if (systemPrompt) {
        addMessage('System Prompt: ' + systemPrompt, 'system', false);
    }
    
    let msg = `Project "${name}" created`;
    if (uploadedFiles.length > 0) {
        msg += ` with ${uploadedFiles.length} file${uploadedFiles.length > 1 ? 's' : ''}`;
    }
    addMessage(msg + '.', 'system', false);
}

function renderProjects() {
    const projects = loadProjectsFromStorage();
    
    if (!projectsList) return;
    projectsList.innerHTML = '';
    
    projects.forEach(project => {
        const item = document.createElement('div');
        item.className = 'project-item' + (project.id === currentProjectId ? ' active' : '');
        item.dataset.projectId = project.id;
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'project-name';
        nameDiv.textContent = project.name;
        nameDiv.onclick = (e) => {
            e.stopPropagation();
            switchProject(project.id);
        };
        item.appendChild(nameDiv);
        
        const menuBtn = document.createElement('button');
        menuBtn.className = 'history-menu-btn';
        menuBtn.style.padding = '2px 4px';
        menuBtn.textContent = '⋮';
        menuBtn.onclick = (e) => {
            e.stopPropagation();
            openProjectMenu(project.id, menuBtn);
        };
        item.appendChild(menuBtn);
        
        projectsList.appendChild(item);
    });
}

function saveGeneratedImages(imageAttachments, prompt) {
    const STORAGE_KEY = 'parakleon_images_v1';
    let images = [];
    
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) images = JSON.parse(raw);
    } catch (e) {
        console.error('Failed to load images', e);
    }
    
    imageAttachments.forEach(img => {
        images.unshift({
            id: 'img_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
            url: img.url,
            name: img.name,
            prompt: prompt,
            projectId: currentProjectId || null,
            chatId: currentChatId || null,
            createdAt: Date.now()
        });
    });
    
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(images));
        renderImages();
    } catch (e) {
        console.error('Failed to save images', e);
    }
}

function renderImages() {
    const STORAGE_KEY = 'parakleon_images_v1';
    const imagesList = document.getElementById('imagesList');
    
    if (!imagesList) return;
    
    let images = [];
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) images = JSON.parse(raw);
    } catch (e) {
        console.error('Failed to load images', e);
    }
    
    imagesList.innerHTML = '';
    
    if (images.length === 0) {
        imagesList.innerHTML = '<div style="padding: 12px; text-align: center; color: #666; font-size: 11px;">No images yet</div>';
        return;
    }
    
    images.forEach(img => {
        const item = document.createElement('div');
        item.className = 'image-item';
        item.style.cssText = 'padding: 8px; border-bottom: 1px solid #222; cursor: pointer; transition: background 0.2s;';
        
        const thumb = document.createElement('img');
        thumb.src = img.url;
        thumb.style.cssText = 'width: 100%; height: 80px; object-fit: cover; border-radius: 4px; border: 1px solid #00FFFF; margin-bottom: 4px;';
        thumb.alt = img.name;
        
        const info = document.createElement('div');
        info.style.cssText = 'font-size: 10px; color: #999; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;';
        info.textContent = img.name;
        
        item.appendChild(thumb);
        item.appendChild(info);
        
        item.onmouseover = () => item.style.background = '#1a1a1a';
        item.onmouseout = () => item.style.background = '';
        
        item.onclick = () => openImageModal(img);
        
        imagesList.appendChild(item);
    });
}

function openImageModal(img) {
    const modal = document.createElement('div');
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); display: flex; flex-direction: column; align-items: center; justify-content: center; z-index: 10000; padding: 20px;';
    
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.style.cssText = 'position: absolute; top: 20px; right: 30px; background: transparent; border: 2px solid #00FFFF; color: #00FFFF; font-size: 32px; cursor: pointer; padding: 5px 15px; border-radius: 4px;';
    closeBtn.onclick = () => document.body.removeChild(modal);
    
    const image = document.createElement('img');
    image.src = img.url;
    image.style.cssText = 'max-width: 90%; max-height: 70%; border: 2px solid #00FFFF; border-radius: 8px; object-fit: contain;';
    
    const info = document.createElement('div');
    info.style.cssText = 'margin-top: 20px; color: #00FFFF; text-align: center; max-width: 600px;';
    info.innerHTML = `
        <div style="font-size: 14px; margin-bottom: 8px;"><strong>${escapeHtml(img.name)}</strong></div>
        <div style="font-size: 12px; color: #999; margin-bottom: 12px;">Generated: ${new Date(img.createdAt).toLocaleString()}</div>
        ${img.prompt ? `<div style="font-size: 11px; color: #666; font-style: italic;">"${escapeHtml(img.prompt.substring(0, 100))}${img.prompt.length > 100 ? '...' : ''}"</div>` : ''}
    `;
    
    const actions = document.createElement('div');
    actions.style.cssText = 'margin-top: 12px; display: flex; gap: 12px; justify-content: center;';
    
    const downloadBtn = document.createElement('a');
    downloadBtn.href = img.url;
    downloadBtn.download = img.name;
    downloadBtn.textContent = '⬇ Download';
    downloadBtn.style.cssText = 'padding: 8px 16px; background: #00FFFF; color: #000; text-decoration: none; border-radius: 4px; font-size: 12px;';
    
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = '🗑 Delete';
    deleteBtn.style.cssText = 'padding: 8px 16px; background: transparent; border: 1px solid #ff0000; color: #ff0000; border-radius: 4px; font-size: 12px; cursor: pointer;';
    deleteBtn.onclick = () => {
        if (confirm('Delete this image?')) {
            deleteImage(img.id);
            document.body.removeChild(modal);
        }
    };
    
    actions.appendChild(downloadBtn);
    actions.appendChild(deleteBtn);
    
    modal.appendChild(closeBtn);
    modal.appendChild(image);
    modal.appendChild(info);
    modal.appendChild(actions);
    
    document.body.appendChild(modal);
}

function deleteImage(imageId) {
    const STORAGE_KEY = 'parakleon_images_v1';
    let images = [];
    
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) images = JSON.parse(raw);
    } catch (e) {
        console.error('Failed to load images', e);
        return;
    }
    
    images = images.filter(img => img.id !== imageId);
    
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(images));
        renderImages();
    } catch (e) {
        console.error('Failed to save images', e);
    }
}

function renderProjects() {
    const projects = loadProjectsFromStorage();
    
    if (!projectsList) return;
    projectsList.innerHTML = '';
    
    projects.forEach(project => {
        const item = document.createElement('div');
        item.className = 'project-item' + (project.id === currentProjectId ? ' active' : '');
        item.dataset.projectId = project.id;
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'project-name';
        nameDiv.textContent = project.name;
        nameDiv.onclick = (e) => {
            e.stopPropagation();
            switchProject(project.id);
        };
        item.appendChild(nameDiv);
        
        const menuBtn = document.createElement('button');
        menuBtn.className = 'history-menu-btn';
        menuBtn.style.padding = '2px 4px';
        menuBtn.textContent = '⋮';
        menuBtn.onclick = (e) => {
            e.stopPropagation();
            openProjectMenu(project.id, menuBtn);
        };
        item.appendChild(menuBtn);
        
        projectsList.appendChild(item);
    });
}

function switchProject(projectId) {
    const projects = loadProjectsFromStorage();
    const project = projects.find(p => p.id === projectId);
    if (!project) return;
    
    currentProjectId = projectId;
    messagesContainer.innerHTML = '';
    
    // Load the project's first chat (or create one if none exists)
    if (project.chats && project.chats.length > 0) {
        currentChatId = project.chats[0].id;
        const chat = project.chats[0];
        
        // Render messages from project chat
        if (chat.messages && chat.messages.length > 0) {
            chat.messages.forEach(msg => {
                addMessage(msg.text, msg.sender, false, msg.attachments || [], msg.id, msg.model);
            });
        }
    } else {
        // Create first chat for project if it doesn't have one
        const chatId = 'chat_' + Date.now();
        project.chats = [{
            id: chatId,
            title: 'Project Chat',
            messages: [],
            starred: false,
            archived: false,
            useFullHistory: true,
            updatedAt: Date.now()
        }];
        currentChatId = chatId;
        saveProjectsToStorage(projects);
    }
    
    renderProjects();
    renderHistory();
    addMessage('Switched to project: ' + project.name, 'system', false);
}

function openProjectMenu(projectId, anchorButton) {
    closeHistoryMenu();
    
    const rect = anchorButton.getBoundingClientRect();
    const containerRect = document.body.getBoundingClientRect();
    
    const menu = document.createElement('div');
    menu.className = 'history-menu';
    
    const editItem = document.createElement('div');
    editItem.className = 'history-menu-item';
    editItem.textContent = 'Rename';
    editItem.onclick = () => {
        renameProject(projectId);
        closeHistoryMenu();
    };
    menu.appendChild(editItem);
    
    const deleteItem = document.createElement('div');
    deleteItem.className = 'history-menu-item';
    deleteItem.textContent = 'Delete project';
    deleteItem.onclick = () => {
        deleteProject(projectId);
        closeHistoryMenu();
    };
    menu.appendChild(deleteItem);
    
    const top = rect.bottom - containerRect.top + window.scrollY;
    const left = rect.left - containerRect.left + window.scrollX;
    menu.style.top = top + 'px';
    menu.style.left = left + 'px';
    
    document.body.appendChild(menu);
    openMenuElement = menu;
}

function renameProject(projectId) {
    const projects = loadProjectsFromStorage();
    const project = projects.find(p => p.id === projectId);
    if (!project) return;
    
    const newName = prompt('New project name:', project.name);
    if (newName && newName.trim()) {
        project.name = newName.trim();
        project.updatedAt = Date.now();
        saveProjectsToStorage(projects);
        renderProjects();
    }
}

function deleteProject(projectId) {
    if (!confirm('Delete this project and all its chats?')) return;
    
    const projects = loadProjectsFromStorage();
    const filtered = projects.filter(p => p.id !== projectId);
    saveProjectsToStorage(filtered);
    
    if (currentProjectId === projectId) {
        currentProjectId = null;
        currentChatId = null;
        messagesContainer.innerHTML = '';
    }
    
    renderProjects();
    renderHistory();
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const hoverStrip = document.getElementById('hoverStrip');
    if (sidebar) sidebar.classList.toggle('hidden');
}

// Auto-open sidebar when cursor approaches left edge (desktop only)
(function setupSidebarHover() {
    if (typeof window === 'undefined') return;
    if ('ontouchstart' in window) return; // skip touch devices

    const HOVER_ZONE = 36; // px from left edge to open
    const CLOSE_DELAY = 1500; // ms delay before closing (1.5 seconds)
    let closeTimer = null;

    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    function openSidebar() {
        if (sidebar.classList.contains('hidden')) {
            sidebar.classList.remove('hidden');
            if (hoverStrip) hoverStrip.classList.add('hidden');
        }
        clearTimeout(closeTimer);
    }
    function closeSidebar() {
        if (!sidebar.classList.contains('hidden')) {
            sidebar.classList.add('hidden');
            if (hoverStrip) hoverStrip.classList.remove('hidden');
        }
    }

    document.addEventListener('mousemove', (e) => {
        const x = e.clientX;

        // open when near left edge
        if (x <= HOVER_ZONE) {
            openSidebar();
        }
    });

    // Simple: close 1.5s after leaving sidebar
    sidebar.addEventListener('mouseenter', () => { 
        clearTimeout(closeTimer);
    });
    sidebar.addEventListener('mouseleave', () => { 
        clearTimeout(closeTimer);
        closeTimer = setTimeout(closeSidebar, CLOSE_DELAY);
    });

    // Hover strip opens sidebar on mouseenter
    if (hoverStrip) {
        hoverStrip.addEventListener('mouseenter', () => { openSidebar(); });
        // keyboard: Enter or Space opens the sidebar
        hoverStrip.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'Spacebar') {
                ev.preventDefault();
                openSidebar();
            } else if (ev.key === 'Escape') {
                ev.preventDefault();
                closeSidebar();
            }
        });
        // hide strip if sidebar starts visible
        if (!sidebar.classList.contains('hidden')) hoverStrip.classList.add('hidden');
    }

    // Global keyboard handling: Escape closes open panels (sidebar or files panel)
    document.addEventListener('keydown', (ev) => {
        if (ev.key === 'Escape') {
            // close files panel if open
            const filesPanel = document.getElementById('filesPanel');
            if (filesPanel && !filesPanel.classList.contains('hidden')) {
                hideFilesPanel();
                ev.stopPropagation();
                return;
            }
            // close sidebar if open
            if (sidebar && !sidebar.classList.contains('hidden')) {
                closeSidebar();
                ev.stopPropagation();
            }
        }
    });
})();

function toggleSection(id) {
    const section = document.getElementById(id);
    const chevronId =
        id === 'projectsSection' ? 'projectsChevron' :
        id === 'favoritesSection' ? 'favoritesChevron' :
        id === 'archiveSection' ? 'archiveChevron' :
        id === 'imagesSection' ? 'imagesChevron' :
        'chatsChevron';
    const chev = document.getElementById(chevronId);
    if (!section || !chev) return;
    section.classList.toggle('collapsed');
    chev.textContent = section.classList.contains('collapsed') ? '►' : '▼';
}

function showThinking() {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ai';
    messageDiv.id = 'thinking-indicator';

    const dotsDiv = document.createElement('div');
    dotsDiv.className = 'thinking-dots';
    dotsDiv.id = 'thinking-dots';
    for (let i = 0; i < 3; i++) {
        const dot = document.createElement('div');
        dot.className = 'dot';
        if (i === 0) dot.classList.add('active');
        dotsDiv.appendChild(dot);
    }

    messageDiv.appendChild(dotsDiv);
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    let dotIndex = 0;
    thinkingInterval = setInterval(() => {
        const dots = document.querySelectorAll('#thinking-dots .dot');
        dots.forEach(d => d.classList.remove('active'));
        dots[dotIndex % 3].classList.add('active');
        dotIndex++;
    }, 600);
}

function removeThinking() {
    clearInterval(thinkingInterval);
    const thinkingDiv = document.getElementById('thinking-indicator');
    if (thinkingDiv) thinkingDiv.remove();
}

messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !isWaiting) {
        sendMessage();
    }
});

function renderTextWithCode(text) {
    const container = document.createElement('div');
    const parts = text.split(/```/g);
    parts.forEach((part, index) => {
        if (index % 2 === 0) {
            if (part.trim()) {
                const p = document.createElement('div');
                p.textContent = part;
                container.appendChild(p);
            }
        } else {
            const codeDiv = document.createElement('div');
            codeDiv.className = 'code-block';
            const pre = document.createElement('pre');
            pre.textContent = part.trim();
            codeDiv.appendChild(pre);

            const copyBtn = document.createElement('button');
            copyBtn.className = 'code-copy-btn';
            copyBtn.textContent = 'Copy';
            copyBtn.onclick = async () => {
                try {
                    await navigator.clipboard.writeText(part.trim());
                    copyBtn.textContent = 'Copied';
                    setTimeout(() => { copyBtn.textContent = 'Copy'; }, 1200);
                } catch (e) {
                    copyBtn.textContent = 'Error';
                    setTimeout(() => { copyBtn.textContent = 'Copy'; }, 1200);
                }
            };
            codeDiv.appendChild(copyBtn);

            container.appendChild(codeDiv);
        }
    });
    return container;
}

function addMessage(text, sender = 'user', persist = true, attachments = [], messageId = null, model = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    if (messageId) {
        messageDiv.dataset.messageId = messageId;
    }

    if (sender === 'user') {
        const label = document.createElement('span');
        label.className = 'message-label';
        label.textContent = 'You:';
        messageDiv.appendChild(label);
    } else if (sender === 'ai') {
        const icon = document.createElement('img');
        // Use the icchat icon from the img/ folder; fallback to alt text if missing
        icon.src = 'img/icchat.png';
        icon.className = 'ai-icon';
        icon.alt = 'Chat';
        messageDiv.appendChild(icon);
        
        // Add model indicator if available
        if (model) {
            console.log('Adding model label:', model);
            const modelLabel = document.createElement('span');
            modelLabel.className = 'model-label';
            modelLabel.textContent = model;
            modelLabel.title = 'Generated by ' + model;
            messageDiv.appendChild(modelLabel);
        } else {
            console.log('No model provided for AI message');
        }
    } else if (sender === 'system') {
        messageDiv.classList.add('system');
    }

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';

    if (sender === 'ai') {
        const content = renderTextWithCode(text);
        bubble.appendChild(content);
    } else {
        bubble.textContent = text;
    }
    messageDiv.appendChild(bubble);

    if (sender === 'user') {
        const actions = document.createElement('div');
        actions.className = 'message-actions';

        const editBtn = document.createElement('button');
        editBtn.className = 'message-action-btn';
        editBtn.textContent = '✎';
        editBtn.title = 'Edit message';
        editBtn.onclick = () => {
            startEditMessage(messageDiv, text);
        };
        actions.appendChild(editBtn);
        messageDiv.appendChild(actions);
    }

    if (attachments && attachments.length > 0) {
        const attachContainer = document.createElement('div');
        attachContainer.className = 'message-attachments';
        
        attachments.forEach(att => {
            if (att.type && att.type.startsWith('image/')) {
                const imgWrapper = document.createElement('div');
                imgWrapper.className = 'message-image-wrapper';
                
                const img = document.createElement('img');
                img.src = att.previewUrl || att.url || '';
                img.className = 'message-image';
                img.alt = att.name || 'Image';
                img.onclick = () => window.open(img.src, '_blank');
                img.style.cursor = 'pointer';
                
                imgWrapper.appendChild(img);
                
                // Add download link
                const downloadLink = document.createElement('a');
                downloadLink.href = img.src;
                downloadLink.download = att.name || 'image.png';
                downloadLink.className = 'image-download-link';
                downloadLink.textContent = '⬇ Download';
                downloadLink.title = 'Download image';
                imgWrapper.appendChild(downloadLink);
                
                attachContainer.appendChild(imgWrapper);
            } else if (att.name) {
                const span = document.createElement('div');
                span.className = 'file-preview';
                span.textContent = 'Attached: ' + att.name;
                attachContainer.appendChild(span);
            }
        });
        
        bubble.appendChild(attachContainer);
    }

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    if (persist) {
        appendMessageToCurrentChat(sender, text, attachments, messageId, model);
    }
}

function startEditMessage(messageElement, originalText) {
    const id = messageElement.dataset.messageId;
    if (!id) return;
    
    // Set edit mode
    editingMessageId = id;
    messageInput.value = originalText;
    messageInput.focus();
    messageInput.select();
    
    // Visual feedback
    messageElement.style.opacity = '0.6';
    messageElement.style.border = '1px solid #00FFFF';
}

async function sendMessage() {
    const text = messageInput.value.trim();
    if (!text || isWaiting) return;

    // Create chat on first message if needed
    ensureCurrentChat();

    const attachments = collectCurrentAttachments();
    addMessage(text, 'user', true, attachments);
    messageInput.value = '';
    clearFileSelection();

    let chats = loadChatsFromStorage();
    const chat = getCurrentChat(chats);
    const useFull = chat ? chat.useFullHistory !== false : true;

    const historyMessages = chat ? chat.messages.slice() : [];
    const toSend = useFull
        ? historyMessages
        : historyMessages.slice(-MAX_SHORT_HISTORY);

    isWaiting = true;
    sendBtn.disabled = true;
    sendBtn.style.display = 'none';
    stopBtn.style.display = 'block';
    abortController = new AbortController();
    showThinking();

    try {
        const payload = buildApiPayload(text, toSend, attachments);
        const response = await callModelApi(payload);
        removeThinking();
        
        // If response contains images, add them as attachments
        const imageAttachments = response.images && response.images.length > 0
            ? response.images.map(url => ({
                type: 'image/png',
                url: url,
                previewUrl: url,
                name: url.split('/').pop() || 'image.png'
            }))
            : [];
        
        // Save generated images to storage
        if (imageAttachments.length > 0) {
            saveGeneratedImages(imageAttachments, text);
        }
        
        addMessage(response.text, 'ai', true, imageAttachments, null, ACTIVE_MODEL);
    } catch (err) {
        console.error(err);
        removeThinking();
        if (err.name === 'AbortError') {
            addMessage('Generation stopped by user.', 'system', true);
        } else {
            addMessage('Error: ' + (err.message || 'Request failed'), 'system', true);
        }
    } finally {
        isWaiting = false;
        sendBtn.disabled = false;
        sendBtn.style.display = 'block';
        stopBtn.style.display = 'none';
        abortController = null;
    }
}

function collectCurrentAttachments() {
    const files = fileInput.files;
    if (!files || !files.length) return [];
    const arr = [];
    for (let i = 0; i < files.length; i++) {
        arr.push({
            name: files[i].name,
            type: files[i].type,
            size: files[i].size
        });
    }
    return arr;
}

function clearFileSelection() {
    fileInput.value = '';
    filePreview.textContent = '';
    fileActions.style.display = 'none';
}

function buildApiPayload(userText, historyMessages, attachments) {
    const messages = [];

    historyMessages.forEach(m => {
        if (m.sender === 'user' || m.sender === 'ai') {
            messages.push({
                role: m.sender === 'user' ? 'user' : 'assistant',
                content: m.text
            });
        }
    });

    let userContent = userText;
    if (attachments && attachments.length > 0) {
        userContent += '\n\n[User attached files metadata: ' +
            JSON.stringify(attachments.map(a => ({name: a.name, type: a.type, size: a.size}))) +
            ']';
    }

    messages.push({role: 'user', content: userContent});

    return {
        model: ACTIVE_MODEL,
        messages
    };
}

async function callModelApi(payload) {
    const headers = {
        'Content-Type': 'application/json'
    };

    if (ACTIVE_API_KEY && ACTIVE_API_KEY !== 'ollama') {
        headers['Authorization'] = 'Bearer ' + ACTIVE_API_KEY;
    }

    const resp = await fetch(ACTIVE_BASE_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        signal: abortController ? abortController.signal : null
    });

    if (!resp.ok) {
        const txt = await resp.text();
        throw new Error('HTTP ' + resp.status + ': ' + txt);
    }

    const data = await resp.json();
    const choice = data.choices && data.choices[0];
    if (!choice || !choice.message || !choice.message.content) {
        throw new Error('Invalid API response');
    }
    
    // Check if response contains image URLs or file paths
    const responseContent = choice.message.content;
    const imageUrls = extractImageUrls(responseContent);
    
    return {
        text: responseContent,
        images: imageUrls
    };
}

function stopGeneration() {
    if (abortController) {
        abortController.abort();
    }
}

function extractImageUrls(text) {
    const urls = [];
    
    // Match markdown image syntax: ![alt](url)
    const markdownRegex = /!\[.*?\]\((.*?)\)/g;
    let match;
    while ((match = markdownRegex.exec(text)) !== null) {
        urls.push(match[1]);
    }
    
    // Match direct URLs to images
    const urlRegex = /(https?:\/\/[^\s]+\.(?:png|jpg|jpeg|gif|webp|svg))/gi;
    while ((match = urlRegex.exec(text)) !== null) {
        if (!urls.includes(match[1])) {
            urls.push(match[1]);
        }
    }
    
    // Match local file paths that might be images
    const fileRegex = /([a-zA-Z]:\\[^\s]+\.(?:png|jpg|jpeg|gif|webp|svg)|\/[^\s]+\.(?:png|jpg|jpeg|gif|webp|svg))/gi;
    while ((match = fileRegex.exec(text)) !== null) {
        if (!urls.includes(match[1]) && !match[1].includes('http')) {
            // Convert local path to server URL
            const filename = match[1].split(/[\\\/]/).pop();
            urls.push('/uploads/' + filename);
        }
    }
    
    return urls;
}

fileInput.addEventListener('change', () => {
    const files = fileInput.files;
    if (!files || !files.length) {
        filePreview.textContent = '';
        fileActions.style.display = 'none';
        return;
    }
    const names = [];
    for (let i = 0; i < files.length; i++) {
        names.push(files[i].name);
    }
    filePreview.textContent = 'Selected file(s): ' + names.join(', ');
    fileActions.style.display = 'flex';
});

function triggerFileUpload() {
    fileInput.click();
}

function sendSmartFileAction(action) {
    const files = fileInput.files;
    if (!files || !files.length) return;
    const names = [];
    for (let i = 0; i < files.length; i++) {
        names.push(files[i].name + ' (' + files[i].type + ', ' + files[i].size + ' bytes)');
    }
    messageInput.value =
        (action === 'summarize'
            ? 'Summarize these files: '
            : action === 'keypoints'
            ? 'Give key points from these files: '
            : 'Explain the code in these files: '
        ) + names.join(', ');
    sendMessage();
}

function showNotification(label) {
    // Route certain notification labels to tools
    if (label && label.toLowerCase().includes('ip')) {
        if (window.ParakleonTools && typeof window.ParakleonTools.ipInfo === 'function') {
            window.ParakleonTools.ipInfo();
            return;
        }
    }
    addMessage('Action: ' + label + ' clicked (coming soon).', 'system', true);
}

function networkAction(event) {
    // Open a small network tools menu anchored to the Network button
    const existing = document.getElementById('network-tools-menu');
    if (existing) {
        existing.remove();
        return;
    }

    // Position the menu centered below the header for consistent placement
    const headerEl = document.querySelector('.header');
    const headerRect = headerEl && headerEl.getBoundingClientRect ? headerEl.getBoundingClientRect() : { bottom: 40, left: 40, width: 600 };

    const menu = document.createElement('div');
    menu.id = 'network-tools-menu';
    menu.className = 'network-menu';
    menu.style.position = 'absolute';
    // place below header and centered horizontally relative to header
    const topPos = headerRect.bottom + window.scrollY + 6; // small gap
    const leftPos = (headerRect.left + window.scrollX) + (headerRect.width / 2) - 90; // menu width ~180
    menu.style.top = topPos + 'px';
    menu.style.left = Math.max(8, leftPos) + 'px';
    menu.style.zIndex = 10000;

    const items = [
        { id: 'ip', label: 'IP Info' },
        { id: 'dns', label: 'DNS Lookup' },
        { id: 'http', label: 'HTTP Header Check' },
        { id: 'ping', label: 'Ping Host' },
        { id: 'port', label: 'Port Scan' }
    ];

    items.forEach(it => {
        const el = document.createElement('div');
        el.className = 'network-menu-item';
        el.textContent = it.label;
        el.style.padding = '8px 10px';
        el.style.cursor = 'pointer';
        el.style.borderRadius = '4px';
        el.onmouseenter = () => el.style.background = '#f3f4f6';
        el.onmouseleave = () => el.style.background = 'transparent';
        el.onclick = (e) => {
            e.stopPropagation();
            menu.remove();
            if (it.id === 'ip') {
                if (window.ParakleonTools && typeof window.ParakleonTools.ipInfo === 'function') {
                    window.ParakleonTools.ipInfo();
                }
            } else if (it.id === 'dns') {
                if (window.ParakleonTools && typeof window.ParakleonTools.dnsLookup === 'function') {
                    window.ParakleonTools.dnsLookup();
                }
            } else if (it.id === 'http') {
                if (window.ParakleonTools && typeof window.ParakleonTools.httpHeaders === 'function') {
                    window.ParakleonTools.httpHeaders();
                }
            } else if (it.id === 'ping') {
                if (window.ParakleonTools && typeof window.ParakleonTools.ping === 'function') {
                    window.ParakleonTools.ping();
                }
            } else if (it.id === 'port') {
                if (window.ParakleonTools && typeof window.ParakleonTools.portScan === 'function') {
                    window.ParakleonTools.portScan();
                }
            }
        };
        menu.appendChild(el);
    });

    document.body.appendChild(menu);

    // Close menu when clicking outside
    const onDocClick = (ev) => {
        if (!menu.contains(ev.target)) {
            menu.remove();
            document.removeEventListener('click', onDocClick);
        }
    };
    setTimeout(() => document.addEventListener('click', onDocClick), 0);
}

function init() {
    renderProjects();
    renderHistory();
}

// Initialize on load
window.addEventListener('DOMContentLoaded', init);
// ===== INITIALIZATION & EVENT WIRING =====

// Ensure init runs on load
function initParakleon() {
    console.log('[Parakleon] Initializing...');
    
    // Ensure message input is focused
    if (messageInput) {
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey && !isWaiting) {
                e.preventDefault();
                sendMessage();
            }
        });
    }
    
    // Ensure Send button is wired
    if (sendBtn) {
        sendBtn.onclick = sendMessage;
    }
    
    // Initialize chat UI
    renderHistory();
    renderImages();
    
    console.log('[Parakleon] Initialized successfully');
}

// Call on page load
if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initParakleon);
    } else {
        initParakleon();
    }
}
